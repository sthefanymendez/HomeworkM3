# Módulo 3 Back End | Node

## **📌 Temas de la homework**

-  Node.js

<br />

---

## **🕒 Duración total estimada**

x minutos

<br />

---

## **🔎 Aprendizaje esperado**

Al finalizar esta homework habrás:

-  Aprendido a crear comandos para Node.
-  Tener un mejor entendimiento sobre cómo funciona una terminal de Node por detrás.
-  Variables globales de Node.

<br />

---

## **📎 ¿Cómo lo lograremos?**

Esta homework está estructurada en una sola carpeta:

1. Puedes enfocarte en realizar los ejercicios de la carpeta [01- Exercises](./01%20-%20Exercises/README.md).
